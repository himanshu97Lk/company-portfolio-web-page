function changeText() {
    const button = document.querySelector('button');
    button.textContent = 'You clicked me!';
}
